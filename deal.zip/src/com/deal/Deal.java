package com.deal;

public class Deal {
	public static void main(String[] args) {
		System.out.println("ȣ����");
	}
		
}
